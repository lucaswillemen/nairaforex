<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Conta extends CI_Controller {

    public function __construct() {
        parent::__construct();
    }

    public function index() {

        $data['titulo'] = 'Backoffice';

        $data['login'] = $this->conta_model->user('login');
        $data['cotas'] = $this->conta_model->MinhasCotas('index');
        $data['indicador'] = $this->conta_model->MeuIndicador();
        $data['anuncios'] = $this->conta_model->Anuncios();

        $this->load->view('conta/templates/header', $data);
        $this->load->view('conta/index');
        $this->load->view('conta/templates/footer');
    }

    public function redirecionar($id) {

        $redirecionamento = $this->conta_model->Redirecionar($id);

        if ($redirecionamento !== false) {

            redirect($redirecionamento);
        } else {

            redirect('conta');
        }
    }

    public function cotas() {

        $data['titulo'] = 'Minhas cotas';

        $data['cotas'] = $this->conta_model->MinhasCotas();

        $this->load->view('conta/templates/header', $data);
        $this->load->view('conta/cotas/todas');
        $this->load->view('conta/templates/footer');
    }

    public function comprar_cotas() {

        $data['titulo'] = 'Comprar cotas';

        $data['contas'] = $this->conta_model->ContasBancarias();

        $this->load->view('conta/templates/header', $data);
        $this->load->view('conta/cotas/comprar');
        $this->load->view('conta/templates/footer');
    }

    public function faturas() {

        $data['titulo'] = 'Faturas';

        $data['faturas'] = $this->conta_model->Faturas();

        $this->load->view('conta/templates/header', $data);
        $this->load->view('conta/financeiro/faturas');
        $this->load->view('conta/templates/footer');
    }

    public function pagar_fatura($id) {

        $data['titulo'] = 'Pagar Fatura';

        $data['fatura'] = $this->conta_model->InformacaoFatura($id);
        $data['contas'] = $this->conta_model->ContasBancarias();

        $this->load->view('conta/templates/header', $data);
        $this->load->view('conta/financeiro/faturas_pagar');
        $this->load->view('conta/templates/footer');
    }

    public function cancelar_fatura($id) {

        $this->conta_model->CancelarFatura($id);

        redirect('faturas');
    }

    public function extrato() {

        $data['titulo'] = 'Extrato';

        $data['extrato_registros'] = $this->conta_model->Extrato();

        $this->load->view('conta/templates/header', $data);
        $this->load->view('conta/financeiro/extrato');
        $this->load->view('conta/templates/footer');
    }

    public function transferir() {

        $data['titulo'] = 'Transferir Saldo';

        if ($this->input->post('submit')) {

            $data['message'] = $this->conta_model->TransferirSaldo();
        }

        $this->load->view('conta/templates/header', $data);
        $this->load->view('conta/financeiro/transferir');
        $this->load->view('conta/templates/footer');
    }

    public function pagar_saldo() {

        $data['titulo'] = 'Pagar faturas com saldo';

        if ($this->input->post('submit2')) {

            $data['message'] = $this->conta_model->PagarFaturaSaldo();
        }

        $this->load->view('conta/templates/header', $data);
        $this->load->view('conta/financeiro/pagar_saldo');
        $this->load->view('conta/templates/footer');
    }

    public function comprovante() {

        $data['titulo'] = 'Enviar comprovante';

        $data['faturas'] = $this->conta_model->Faturas();

        if ($this->input->post('submit')) {

            $data['message'] = $this->conta_model->EnviarComprovante();
        }

        $this->load->view('conta/templates/header', $data);
        $this->load->view('conta/financeiro/comprovante');
        $this->load->view('conta/templates/footer');
    }

    public function saque() {

        $data['titulo'] = 'Saques';

        $data['saques'] = $this->conta_model->Saques();

        $this->load->view('conta/templates/header', $data);
        $this->load->view('conta/financeiro/saques');
        $this->load->view('conta/templates/footer');
    }

    public function solicitar_saque() {

        $this->load->helper('bancos');

        $data['titulo'] = 'Solicitar Saque';

        if ($this->input->post('submit')) {

            $data['message'] = $this->conta_model->SolicitarSaque();
        }

        $this->load->view('conta/templates/header', $data);
        $this->load->view('conta/financeiro/saques_solicitar');
        $this->load->view('conta/templates/footer');
    }

    public function configuracoes() {

        $this->load->helper('bancos');

        $data['titulo'] = 'Configurações';

        if ($this->input->post('submit1')) {

            $data['message1'] = $this->conta_model->AtualizarDados();
        }

        if ($this->input->post('submit2')) {

            $data['message2'] = $this->conta_model->AlterarSenha();
        }

        if ($this->input->post('submit3')) {

            $data['message3'] = $this->conta_model->AlterarContaBancaria();
        }

        $data['bancos'] = Bancos();

        $this->load->view('conta/templates/header', $data);
        $this->load->view('conta/usuario/configuracoes');
        $this->load->view('conta/templates/footer');
    }

    public function indicados() {

        $this->load->model('admin_model');

        $data['titulo'] = 'Minha Rede';

        if (isset($_GET['rede'])) {
            $filhos = $this->admin_model->filhos($this->native_session->get('user_id'));
            if (in_array($_GET['rede'], $filhos)) {
                $data['indicados'] = $this->conta_model->Indicados($_GET['rede']);
            } else {
                echo '<center><h1>Esse usuário não pertence a sua rede</h1></center>';
                exit();
            }
        } else {
            $data['indicados'] = $this->conta_model->Indicados();
        }

        $data['conta_model'] = $this->conta_model;
        $data['admin_model'] = $this->admin_model;


        $this->load->view('conta/templates/header', $data);
        $this->load->view('conta/indicados');
        $this->load->view('conta/templates/footer');
    }

    public function tickets() {

        $this->load->helper('tickets');

        $data['titulo'] = 'Tickets';

        $data['tickets'] = $this->conta_model->TodosTickets();

        $this->load->view('conta/templates/header', $data);
        $this->load->view('conta/tickets/todos');
        $this->load->view('conta/templates/footer');
    }

    public function novo_ticket() {

        $data['titulo'] = 'Novo Ticket';

        if ($this->input->post('submit')) {

            $data['message'] = $this->conta_model->NovoTicket();
        }

        $this->load->view('conta/templates/header', $data);
        $this->load->view('conta/tickets/novo');
        $this->load->view('conta/templates/footer');
    }

    public function visualizar_ticket($id) {

        $data['titulo'] = 'Visualizar Ticket';

        if ($this->input->post('submit')) {

            $this->conta_model->AdicionarMensagemTicket($id);
        }

        $data['ticket'] = $this->conta_model->InformacaoTicket($id);
        $data['ticket_mensagens'] = $this->conta_model->MensagensTicket($id);

        $this->load->view('conta/templates/header', $data);
        $this->load->view('conta/tickets/visualizar');
        $this->load->view('conta/templates/footer');
    }

    public function atualiza_notificacao() {

        echo $this->conta_model->AtualizaNotificacoes();
    }

    public function sair() {

        $this->native_session->unset_userdata('user_id');
        redirect('login');
    }

}
